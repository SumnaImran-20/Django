from email import message
from multiprocessing import context
import re
from unicodedata import name
from urllib import request
from django.shortcuts import render, HttpResponse
from Home.models import Contact
from datetime import datetime
from django.contrib import messages
from django.contrib.auth.models import User
from django.contrib.auth import authenticate

# Create your views here.
def index(request):
    context={
        "value": "hello",
        "value2": "World",
        "value3": "!"
    }
    messages.success(request,"this is test meassage")
    return render(request,'index.html',context)  #dosra argumnet ha template ka naam
    #return HttpResponse("This is home page")

def about(request):
    return render(request,'aboutus.html')

def facilities(request):
    return render(request,'facilities.html')
     
def services(request):
    return render(request,'services.html')

def predictions(request):
    return render(request,'pridictions.html')

def contactus(request):
    if request.method == "POST":
        name = request.POST.get('name')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        decs = request.POST.get('desc')
        contact = Contact(name=name,email=email,phone=phone,decs=decs, date=datetime.today())
        contact.save()
        messages.success(request, 'Form Have Been Submitted')

    return render(request,'contactus.html')

"""def facilityregister(request):
    if request.method == "POST":
        username = request.POST.get('username')
        fname = request.POST.get('fname')
        lname = request.POST.get('lname')
        email = request.POST.get('email')
        cnic = request.POST.get('cnic')
        phone = request.POST.get('phone')
        password = request.POST.get('password')
        conpassword = request.POST.get('conpassword')
        contact = Contact(name=name,email=email,phone=phone,decs=decs, date=datetime.today())
        contact.save()
        messages.success(request, 'Form Have Been Submitted')
   
    return render(request,'facilityregister.html')
"""

""""    
def facilitylogin(request):
    return render(request,'facilitylogin.html')
"""